package com.gcb.shift;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class GcbWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        updateAll(ctx, mgr, ids);
    }

    static void updateAll(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) {
            mgr.updateAppWidget(id, build(ctx));
        }
    }

    private static long days(String a, String b) throws Exception {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        long ms = f.parse(b).getTime() - f.parse(a).getTime();
        return Math.round(ms / 86400000.0);
    }

    static RemoteViews build(Context ctx) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_gcb);
        String status = "GCB Shift";
        String big = "—";
        String small = "";

        try {
            SharedPreferences sp = ctx.getSharedPreferences("CapacitorStorage", Context.MODE_PRIVATE);
            String raw = sp.getString("widget_data", null);
            if (raw != null) {
                JSONObject o = new JSONObject(raw);
                JSONObject lb = o.getJSONObject("labels");
                JSONArray rots = o.getJSONArray("rots");
                Locale loc = Locale.forLanguageTag(o.optString("loc", "fr-FR"));
                String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());

                String bestKind = null;
                String bestEnd = null;
                long bestRemaining = 0;
                int bestRank = 99;

                for (int i = 0; i < rots.length(); i++) {
                    JSONObject r = rots.getJSONObject(i);
                    String s = r.getString("s");
                    String w = r.getString("w");
                    String e = r.getString("e");
                    String kind;
                    String end;
                    int rank;
                    if (today.compareTo(s) < 0) {
                        kind = "upcoming"; end = s; rank = 2;
                    } else if (today.compareTo(w) <= 0) {
                        kind = "work"; end = w; rank = 0;
                    } else if (today.compareTo(e) <= 0) {
                        kind = "rest"; end = e; rank = 0;
                    } else {
                        kind = "done"; end = e; rank = 3;
                    }
                    boolean better = false;
                    if (bestKind == null || rank < bestRank) {
                        better = true;
                    } else if (rank == bestRank) {
                        if (rank == 2 && end.compareTo(bestEnd) < 0) better = true;   // nearest upcoming
                        if (rank == 3 && end.compareTo(bestEnd) > 0) better = true;   // latest finished
                    }
                    if (better) {
                        bestKind = kind; bestEnd = end; bestRank = rank;
                        bestRemaining = "done".equals(kind) ? 0 : days(today, end);
                    }
                }

                if (bestKind != null) {
                    status = lb.optString(bestKind, bestKind);
                    big = String.valueOf(bestRemaining);
                    String endTxt = new SimpleDateFormat("d MMM yyyy", loc).format(
                            new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(bestEnd));
                    small = lb.optString("days", "") + " · " + lb.optString("until", "") + " " + endTxt;
                } else {
                    status = lb.optString("open", "GCB Shift");
                }
            }
        } catch (Exception ignored) {
        }

        v.setTextViewText(R.id.widget_status, status);
        v.setTextViewText(R.id.widget_big, big);
        v.setTextViewText(R.id.widget_small, small);

        Intent open = new Intent(ctx, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        v.setOnClickPendingIntent(R.id.widget_root, PendingIntent.getActivity(ctx, 0, open, flags));
        return v;
    }
}
