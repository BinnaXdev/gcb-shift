package com.gcb.shift;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "GcbWidget")
public class GcbWidgetPlugin extends Plugin {

    @PluginMethod
    public void refresh(PluginCall call) {
        Context ctx = getContext();
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, GcbWidgetProvider.class));
        if (ids != null && ids.length > 0) {
            GcbWidgetProvider.updateAll(ctx, mgr, ids);
        }
        call.resolve();
    }
}
