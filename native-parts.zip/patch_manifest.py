import sys
p = sys.argv[1]
s = open(p, encoding="utf-8").read()
perms = """    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
"""
receiver = """        <receiver android:name=".GcbWidgetProvider" android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/gcb_widget_info" />
        </receiver>
"""
if "GcbWidgetProvider" not in s:
    s = s.replace("</application>", receiver + "    </application>", 1)
if "POST_NOTIFICATIONS" not in s:
    s = s.replace("<application", perms + "    <application", 1)
open(p, "w", encoding="utf-8").write(s)
print("manifest patched")
